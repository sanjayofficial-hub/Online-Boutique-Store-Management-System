
<div class="header-bottom" >
    <div class="col-sm-12" style="height: 120px">
                <div class="mainmenu pull-left">
                    <ul class="nav navbar-nav collapse navbar-collapse">
                        <li><a href="#"><img src="images/logo.png" alt=""  height="150px" width="150px" style="margin-left: 0px;margin-top: 0px"/></a></li>
                        <li><a href="index.php" class="active"  style="padding-top: 30px;padding-left: 130px"><i class="fa fa-home"></i>  Home </a></li>
                        <li  style="padding-top: 30px;padding-left: 50px"><a href="aboutus.php"><i class="fa fa-info-circle"></i>  About Us</a></li>
                        
                        <li class="dropdown" style="padding-top: 30px;padding-left: 50px">
                            <a href="#"><i class="fa fa-female"></i> Catalog</a>
                            <ul role="menu" class="sub-menu" style="width: 500px">
                                <li><a href="kurti.php">Kurtis</a></li>
                                <li><a href="salwarSuit.php">Salwar Suits</a></li>  
                                <li><a href="saree.php">Sarees</a></li>
                                <li><a href="dresses.php">Dresses</a></li>
                                <li><a href="chaniyaCholi.php">Chaniya Cholis</a></li> 
                                <li><a href="gowns.php">Gowns</a></li>
                                <li><a href="indoWestern.php">Indo Western</a></li>
                            </ul>
                        </li> 
                        <li  style="padding-top: 30px;padding-left: 50px"><a href="registration.php"><i class="fa fa-user-plus"></i> Register</a></li>
                        <li  style="padding-top: 30px;padding-left: 50px"><a href="login.php"><i class="fa fa-lock"></i> Login</a></li>
                        <li  style="padding-top: 30px;padding-left: 40px">
                            
                            <a href="addtoCart.php">
                                <i class="fa fa-shopping-cart"> </i>  Cart
                            </a>
                            
                        </li>
                        <li  style="padding-top: 30px;padding-left: 50px"><a href="contactus.php"><i class="fa fa-envelope"></i>  Contact US </a></li>
                      </ul>
            </div>
                
         </div>
</div>
