
<div class="footer-widget" style="margin-left: 230px">
        <div class="container" >
            <div class="row">
                <div class="col-md-3">
                    <div class="single-widget">
                        <h2>Service</h2>
                        <ul class="nav nav-pills nav-stacked">
                            <li><a href="#">Online Help</a></li>
                            <li><a href="contactus.php">Contact Us</a></li>
                            <li><a href="#">Order Status</a></li>
                            <li><a href="#">FAQ’s</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="single-widget">
                        <h2>Quick Shop</h2>
                        <ul class="nav nav-pills nav-stacked">
                            <li><a href="kurti.php">Kurtis</a></li>
                            <li><a href="dresses.php">Dresses</a></li>
                            <li><a href="saree.php">Sarees</a></li>
                            <li><a href="chaniyaCholi.php">Chaniya Choli</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="single-widget">
                        <h2>Policies</h2>
                        <ul class="nav nav-pills nav-stacked">
                            <li><a href="#">Terms of Use</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="single-widget">
                        <h2>About Shopper</h2>
                        <ul class="nav nav-pills nav-stacked">
                            <li><a href="aboutus.php">About Us</a></li>
                            <li><a href="#">Copyright</a></li>
                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <p class="pull-left" style="margin-left: 400px;">Copyright © 2021 BMIIT Project Inc. All rights reserved.</p>
            </div>
        </div>
    </div>